CR2032 Battery Container for 5pcs by NerdCorner on Thingiverse: https://www.thingiverse.com/thing:6961021

Summary:
Find out everything you need to know about the battery box on my blog:https://nerd-corner.com/3d-printed-battery-container-for-cr2032/orhttps://nerd-corner.com/de/3d-gedruckter-batteriebehaelter-fuer-cr2032/